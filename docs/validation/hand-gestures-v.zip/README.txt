MomoPoseForge 姿态导出 v2

每个视角：mannequin.png 是素体参考；openpose-body-hands.png 是身体 COCO18 + 双手各21点的黑底骨架控制图。
keypoints-openpose.json 使用 OpenPose 1.3 字段，像素坐标 x,y,c；每手从手腕开始，依次为拇指、食指、中指、无名指、小指，每指4点。
c=1 是程序生成的有效点，不是 AI 检测置信度。出画面点为0；手部按所选遮挡设置过滤，判断容差见 manifest.json。未输出面部点集。
openpose-coco18.png 和 keypoints-coco18.json 是保留的身体18点兼容文件。skeleton-world.json 是完整身体/手部的米制三维坐标，不是 OpenPose 的三角测量结果。
depth.png：相机轴向深度线性归一化，近白远黑，五视图共用范围；normal.png：相机表面法线的 ControlNet 1.1 / ScanNet 可视化约定。数据图不含灯光、色调映射或 sRGB 转换。
mask.png：白色是角色，黑色是背景。用它区分深度/法线图的背景；相机和深度范围完整记录在 manifest.json。
workflow-controlnet.json 提供固定模型版本、通道权重、种子与匹配画幅的生成配置（最长边512，8像素对齐）。非整比时等比缩放后补黑边，不拉伸控制图。ZIP 同时附带运行脚本、依赖和模型版本清单。
本地复现：解压本 ZIP，在解压目录中创建 Python 虚拟环境，安装匹配显卡的 CUDA PyTorch，再 pip install -r tools/requirements-controlnet.txt；运行 python tools/run-controlnet.py 原ZIP路径 --ablation。首次运行下载约5GB公开模型，需要CUDA显卡。
可用 --view 选择视角、--prompt 修改人物/服装描述、--seed 固定随机种子；--model-cache 指定模型缓存。已有模型时加 --offline。直接使用控制图，不要再做姿态/深度/法线估计。
真实生成仍取决于所选模型和权重；X Bot 分段几何会进入深度/法线图，独立生成不同视角不会自动保证角色身份一致。
参考图片为视口叠加层，不进入任何 PNG、深度、法线或关键点；如勾选工程，图片内嵌在 project.pose.json 中，可随工程恢复。
project.pose.json 可重新打开编辑；contact-sheet.png 只用于整组查看，单视角工作流使用该视角目录内的独立图。
角色资产：Adobe Mixamo X Bot，https://helpx.adobe.com/creative-cloud/faq/mixamo-faq.html 。
